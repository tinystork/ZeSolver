unit Unit_tycho2;

{$MODE Delphi}


interface

uses
     LCLIntf, LCLType, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
     StdCtrls, Menus,printers;

procedure read_tycho2_supplement(epoch2:real;var ra1,dec1: real; var  mag1, nr_regio,nr_star,nr_extra: integer);
procedure read_tycho2(epoch2:real;var ra1,dec1: real; var  mag1, nr_regio,nr_star,nr_extra: integer);
procedure loadbuffer(naam1:string);

const
  tycho_files: array[0..21] of string=('suppl_1.dat','suppl_2.dat',
                                       'tyc2.dat.00','tyc2.dat.01','tyc2.dat.02','tyc2.dat.03','tyc2.dat.04','tyc2.dat.05','tyc2.dat.06','tyc2.dat.07','tyc2.dat.08','tyc2.dat.09',
                                       'tyc2.dat.10','tyc2.dat.11','tyc2.dat.12','tyc2.dat.13','tyc2.dat.14','tyc2.dat.15','tyc2.dat.16','tyc2.dat.17','tyc2.dat.18','tyc2.dat.19');
var
   readposition : integer;

implementation
uses D290conv;


procedure loadbuffer(naam1:string);
begin
 with bufferstring1 do
 begin
   try
     LoadFromFile(naam1);	{ load from file }
   except;
    {action none}
     clear;
     beep;
     main_form.caption:='Error reading file: '+naam1;
   end;
 end;
 readposition:=0;
end;
procedure read_tycho2_supplement(epoch2:real;var ra1,dec1: real; var  mag1, nr_regio,nr_star,nr_extra: integer);
var
   info  : string;
   error1,error2, error_total:integer;
   mag1r,magVT, magBT,pmRA, pmDEC  : real;
   star_ok: boolean;
begin
   repeat
     info:=copy(bufferstring1.strings[readposition],1,4);{regio}
     val(info,nr_regio,error1); error_total:=error1;
     info:=copy(bufferstring1.strings[readposition],6,5);{star number}
     val(info,nr_star,error1);error_total:=error_total+error1;
     info:=copy(bufferstring1.strings[readposition],12,1);{number extra}
     val(info,nr_extra,error1);error_total:=error_total+error1;
     info:=copy(bufferstring1.strings[readposition],16,12);{RA}
     val(info,ra1,error1);error_total:=error_total+error1;

     info:=copy(bufferstring1.strings[readposition],29,12); {DEC}
     val(info,dec1,error1);error_total:=error_total+error1;

     info:=copy(bufferstring1.strings[readposition],42,7);{pmRA, proper motion RA}
     val(info,pmRA,error1);
     info:=copy(bufferstring1.strings[readposition],50,7);{pmDEC}
     val(info,pmDEC,error1);

     {magnitude}
     info:=copy(bufferstring1.strings[readposition],124,6); {VT magnitude}
     val(info,magVT,error1);{second change using BT magnitude}

     info:=copy(bufferstring1.strings[readposition],111,6); {BT magnitude}
     val(info,magBT,error2);
     error_total:=error_total+error2;

     if ((error1=0) and (error2=0)) then mag1r:=magVT - 0.090 * (magBT - magVT)   {V = VT - 0.090 * (BT - VT)}
     else
     mag1R:=MagBT;{no VT magnitude, use BT instead 25 stars only}

     mag1R:=round(mag1r*10);


     if error_total<>0 then mag1:=999 {ignore this star entry, try next}
     else
     begin {suppl_1.dat and suppl_2.dat files using J1991.25 epoch!!!}
       DEC1 {(epoch T)} := (DEC1 + pmDEC * (epoch2 - 1991.25)/(3600*1000))*  (pi/180);  {DEC first}
       RA1  {(epoch T)} := (RA1  + pmRA / cos(dec1)*(epoch2 - 1991.25)/(3600*1000))*(pi/180);
     end;

     inc(readposition);
     star_ok:=((mag1>=mag_begin*10)  and  (mag1<=(mag_begin+step)*10))
   until ((readposition>=bufferstring1.count) or  (star_ok));
   if star_ok=false then mag1:=1000;{last star is not okay to include in this run}
end;

procedure read_tycho2(epoch2:real;var ra1,dec1: real; var  mag1, nr_regio,nr_star,nr_extra: integer);
var
   info  : string;
   error1,error2, error_total:integer;
   mag1R,magVT, magBT,pmRA, pmDEC  : real;
   star_ok: boolean;
begin
   repeat
//     if pos('4628 00237 1',bufferstring1.strings[readposition])>0 then
//     beep;
     info:=copy(bufferstring1.strings[readposition],1,4);{regio}
     val(info,nr_regio,error1); error_total:=error1;
     info:=copy(bufferstring1.strings[readposition],6,5);{star number}
     val(info,nr_star,error1);error_total:=error_total+error1;
     info:=copy(bufferstring1.strings[readposition],12,1);{number extra}
     val(info,nr_extra,error1);error_total:=error_total+error1;

     if 'X'<>copy(bufferstring1.strings[readposition],14,1) then {normal mean value available}
     begin
       info:=copy(bufferstring1.strings[readposition],16,12);{RA}
       val(info,ra1,error1);error_total:=error_total+error1;
       info:=copy(bufferstring1.strings[readposition],29,12); {DEC}
       val(info,dec1,error1);error_total:=error_total+error1;
       info:=copy(bufferstring1.strings[readposition],42,7);{pmRA, proper motion RA}
       val(info,pmRA,error1);
       info:=copy(bufferstring1.strings[readposition],50,7);{pmDEC}
       val(info,pmDEC,error1);
     end
     else
     begin
       info:=copy(bufferstring1.strings[readposition],153,12);{RA}
       val(info,ra1,error1);error_total:=error_total+error1;
       info:=copy(bufferstring1.strings[readposition],166,12); {DEC}
       val(info,dec1,error1);error_total:=error_total+error1;
       pmRa:=0;{not available}
       pmDec:=0;
     end;

     {magnitude}
     info:=copy(bufferstring1.strings[readposition],124,6); {VT magnitude}
     val(info,magVT,error1);{second change using BT magnitude}

     info:=copy(bufferstring1.strings[readposition],111,6); {BT magnitude}
     val(info,magBT,error2);
     error_total:=error_total+error2;

     if ((error1=0) and (error2=0)) then mag1r:=magVT - 0.090 * (magBT - magVT)   {V = VT - 0.090 * (BT - VT)}
     else
     mag1R:=MagBT;{no VT magnitude, use BT instead 25 stars only}

     mag1:=round(mag1r*10);

     if ((nr_regio=4628) and (nr_star=237)) then {polaris, missing proper motion in tycho-2, add here}
     begin
       ra1:= ( 02 +31/60 +49.09456/3600)*360/24;
       dec1:=(+89 +15/60 +50.7923 /3600);
       mag1:=20;
       pmRA:=44.48;
       pmDEC:=-11.85;
       error_total:=0;
       {simbad query:}
       {polaris, ICRS coord. (ep=J2010, eqJ2000) : 	02 31 49.09456 +89 15 50.7923 }
       {polaris, ICRS coord. (ep=J2016, eqJ2000) : 	02 31 52.78845 +89 15 50.6026 }
       {polaris, ICRS coord. (ep=J2100, eqJ2000) : 	02 32 12.17295 +89 15 49.6035 }
       {polaris, ICRS coord. (ep=J2250, eqJ2000) : 	02 32 46.75267 +89 15 47.8064 }
     end;
     {simbad query:}
     {sirius, ICRS coord. (ep=J2000, eqJ2000) 06 45 08.91728 -16 42 58.0171 }
     {sirius, ICRS coord. (ep=J2016, eqJ2000) 06 45 08.30913 -16 43 17.5868 }
     {sirius, ICRS coord. (ep=J2100, eqJ2000) 06 45 05.11511 -16 45 00.3480 }
     {sirius, ICRS coord. (ep=J2250, eqJ2000) 06 44 59.40628 -16 48 03.9339 }

     {capella, ICRS coord. (ep=J2100, eqJ2000) 05 16 41.35871 +45 59 52.7693 }
     {capella, ICRS coord. (ep=J2016, eqJ2000) 05 16 41.47425 +45 59 45.9390 }
     {capella, ICRS coord. (ep=J2100, eqJ2000) 05 16 42.08070 +45 59 10.0801 }
     {capella, ICRS coord. (ep=J2250, eqJ2000)  05 16 43.16312 +45 58 06.0459}

     if error_total<>0 then mag1:=999 {ignore this star entry, try next }
     else
     begin
       DEC1 {(epoch T)} := (DEC1 + pmDEC * (epoch2 - 2000.0)/(3600*1000))*  (pi/180);  {DEC first}
       RA1  {(epoch T)} := (RA1  + pmRA / cos(dec1)*(epoch2 - 2000.0)/(3600*1000))*(pi/180);
     end;

     inc(readposition);
     star_ok:=((mag1>round(mag_begin*10))  and  (mag1<=round((mag_begin+step)*10))) {magnitude filter, round function to get sharp selection and not star is forgotten or double processec}
   until ((readposition>=bufferstring1.count) or  (star_ok));
   if star_ok=false then mag1:=1000;{last star is not okay to include in this run}
end;

begin  {program}
end.
