pkzip25  -add source_missing_gaia__-%date:/=-%   *.pas *.lfm *.lpi  *.lpr *.lfm *.lpi *.lps *.dof *.cfg *.res *.csv  *.bat *.xls
xcopy source*.zip d:\hnsky_source /s/y/d/c
xcopy source*.zip e:\hnsky_source /s/y/d/c
xcopy source*.zip f:\hnsky_source /s/y/d/c
xcopy source*.zip g:\hnsky_source /s/y/d/c
xcopy source*.zip h:\hnsky_source /s/y/d/c
xcopy source*.zip i:\hnsky_source /s/y/d/c
xcopy source*.zip j:\hnsky_source /s/y/d/c
xcopy source*.zip k:\hnsky_source /s/y/d/c
pause


