unit D290conv;

{$MODE Delphi}

{written for HNSKY quickly from some modules, Han K, 21-2-2015}  
interface

uses
  LCLIntf, LCLType, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ComCtrls, ExtCtrls, Windows, Menus, Buttons,clipbrd, Types;

type
  TMain_form = class(TForm)
    Button1: TButton;
    Label4: TLabel;
    StatusBar1: TStatusBar;
    powerdown_enabled: TCheckBox;
    GroupBox1: TGroupBox;
    Gaia_catalogue: TEdit;
    Label11: TLabel;
    Tycho2_catalogue: TEdit;
    procedure Button1Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;


var
  Main_form: TMain_form;
  step, step2, maximum,mag_begin          :  double;
  bufferstring1,bufferstring2              : Tstrings;
  file_counter                            : integer;
implementation

{$R *.lfm}

var
  nr_of_stars,
  readposition1,readposition2 : integer;


function ShutMeDown:string;
var
  hToken : THandle;
  tkp,p : TTokenPrivileges;
  RetLen : DWord;
  ExReply: LongBool;
  Reply : DWord;
begin
  if OpenProcessToken(GetCurrentProcess,TOKEN_ADJUST_PRIVILEGES or TOKEN_QUERY,hToken) then
  begin
    if LookupPrivilegeValue(nil,'SeShutdownPrivilege',tkp .Privileges[0].Luid) then
    begin
      tkp.PrivilegeCount := 1;
      tkp.Privileges[0].Attributes := SE_PRIVILEGE_ENABLED;
      AdjustTokenPrivileges(hToken,False,tkp,SizeOf(TTokenPrivileges),p,RetLen);
      Reply := GetLastError;
      if Reply = ERROR_SUCCESS then
      begin
        ExReply:= ExitWindowsEx(EWX_POWEROFF or EWX_FORCE, 0);
        if ExReply then Result:='Shutdown Initiated'
        else
        Result:='Shutdown failed with ' + IntToStr(GetLastError);
      end;
    end;
  end;
end;

PROCEDURE ang_sep(ra1,dec1,ra2,dec2 : double;var sep: double); { By Han Kleijn}
var cos_sep: double;
{caculates angular separation. according formula 9.1 old meeus}
Begin
  cos_sep:=sin(dec1)*sin(dec2)+ cos(dec1)*cos(dec2)*cos(ra1-ra2);
  if ABS(cos_sep)<1 then begin sep:=(PI/2-ARCTAN(cos_sep/(SQRT(1-SQR(cos_sep))))) end {arccos function}
  else
  begin if cos_sep>0 then sep:=0 {note bij x=1 klapt uitkomst net om}
                     else sep:=PI;
  end; {arccos function}

end;

function inttostr(inp:integer): string;
begin
  str(inp,result);
end;
function doubletostr(inp:double): string;
begin
  str(inp:0:5,result);
end;

procedure read_gaia(epoch2:double;var ra1,dec1: double; var  mag1: integer);
var
   info  : string;
   error1,error2, error_total,komma1,oldkomma:integer;
   magG,magBP, magRP,pmRA, pmDEC  : double;
   star_ok: boolean;
begin
//old:  ra,dec,source_id,ref_epoch,pmRA,pmdec,duplicated_source,phot_g_mean_mag
//new:  ra,dec,source_id,pmra,pmdec,duplicated_source,phot_g_mean_mag,phot_bp_mean_mag,phot_rp_mean_mag
   repeat
     if ((readposition1>=bufferstring1.count) or (length(bufferstring1.strings[readposition1])<2)) then
     begin
       RA1:=99999;
       exit;
     end;
     if (length(bufferstring1.strings[readposition1])<2) then  {empthy line}
     begin
       inc(readposition2);
       RA1:=99999;
       exit;
     end;


     komma1:=pos(',',bufferstring1.strings[readposition1],1);
     info:=copy(bufferstring1.strings[readposition1],1,komma1-1);{regio}
     val(info,ra1,error1); error_total:=error1;
     oldkomma:=komma1+1;

     komma1:=pos(',',bufferstring1.strings[readposition1],oldkomma);
     info:=copy(bufferstring1.strings[readposition1],oldkomma,komma1-oldkomma);{regio}
     val(info,dec1,error1); error_total:=error1;
     oldkomma:=komma1+1;

     komma1:=pos(',',bufferstring1.strings[readposition1],oldkomma); {SOURCE_ID}
     info:=copy(bufferstring1.strings[readposition1],oldkomma,komma1-oldkomma);{regio}
     oldkomma:=komma1+1;

  //   if info='2739891064118043648' then
//     begin
//         IF pos(',4,19,1,',bufferstring2.strings[readposition2-1])>0 then
//         beep;
//     end;


//   if info='2552926396079008512' then
//     begin
//         IF pos(',17,1398,',bufferstring2.strings[readposition2-1])>0 then
//         beep;
//     end;


//     komma1:=pos(',',bufferstring1.strings[readposition1],oldkomma); {EPOCH =2015}
//     oldkomma:=komma1+1;


     komma1:=pos(',',bufferstring1.strings[readposition1],oldkomma);
     info:=copy(bufferstring1.strings[readposition1],oldkomma,komma1-oldkomma);{pmRA}
     val(info,pmRA,error1);
     oldkomma:=komma1+1;

     komma1:=pos(',',bufferstring1.strings[readposition1],oldkomma);
     info:=copy(bufferstring1.strings[readposition1],oldkomma,komma1-oldkomma); {pmdec}
     val(info,pmDEC,error1);
     oldkomma:=komma1+1;


     komma1:=pos(',',bufferstring1.strings[readposition1],oldkomma); {DUPLICATED SOURCE}
     oldkomma:=komma1+1;

//45.07279145266,0.96998379910,132667245587072,29.579,-93.685,0,7.4630,8.0488,6.7831

     komma1:=pos(',',bufferstring1.strings[readposition1],oldkomma); {}
     info:=copy(bufferstring1.strings[readposition1],oldkomma,6);{G magnitude}
     val(info,magG,error1);
     oldkomma:=komma1+1;

     komma1:=pos(',',bufferstring1.strings[readposition1],oldkomma); {}
     info:=copy(bufferstring1.strings[readposition1],oldkomma,6);{BP magnitude}
     val(info,magBP,error1);
     oldkomma:=komma1+1;

     komma1:=pos(',',bufferstring1.strings[readposition1],oldkomma); {}
     info:=copy(bufferstring1.strings[readposition1],oldkomma,6);{RP magnitude}
     val(info,magRP,error1);
     oldkomma:=komma1+1;

     if ((magBP<>0) and (magRP<>0)) then {calculate V magnitude}
         mag1:=round((magG + 0.01760 + 0.006860 * (magBP-magRP) + 0.1732 * sqr(magBP-magRP))*10)
         else
         mag1:=round((magG+0.3)*10);


     if error_total<>0 then mag1:=999 {ignore this star entry, try next }
     else
     begin                                                       {GAIA 2015 epoch !!!!!!}
       DEC1 {(epoch T)} := (DEC1 + pmDEC * (epoch2 - 2015.5)/(3600*1000))*  (pi/180);  {DEC first}
       RA1  {(epoch T)} := (RA1  + pmRA / cos(dec1)*(epoch2 - 2015.0)/(3600*1000))*(pi/180);
     end;

     inc(readposition1);
   until ((readposition1>=bufferstring1.count) or (error_total=0));
end;

procedure read_Tycho(epoch2:double;var ra1,dec1: double; var  mag1: integer);
var
   info  : string;
   error0,error1,error2, error_total,komma1,oldkomma,tyc1,tyc2,tyc3,hip1:integer;
   mag1R,magVT, magBT,pmRA, pmDEC  : double;
   star_ok: boolean;
begin
   repeat
     if (readposition2>=bufferstring2.count) then
     begin
        RA1:=99999;
        exit;
     end;
     if (length(bufferstring2.strings[readposition2])<2) then  {empthy line}
     begin
        inc(readposition2);
         RA1:=99999;
         exit;
     end;
     error_total:=0;

     komma1:=pos(',',bufferstring2.strings[readposition2],1);
     info:=copy(bufferstring2.strings[readposition2],1,komma1-1);{ra}
     val(info,ra1,error1); error_total:=error_total+error1;
     oldkomma:=komma1+1;

     komma1:=pos(',',bufferstring2.strings[readposition2],oldkomma);
     info:=copy(bufferstring2.strings[readposition2],oldkomma,komma1-oldkomma);{dec}
     val(info,dec1,error1); error_total:=error_total+error1;
     oldkomma:=komma1+1;

     komma1:=pos(',',bufferstring2.strings[readposition2],oldkomma);
     info:=copy(bufferstring2.strings[readposition2],oldkomma,komma1-oldkomma);{tyc1}
     val(info,tyc1,error1);
     oldkomma:=komma1+1;

     komma1:=pos(',',bufferstring2.strings[readposition2],oldkomma);
     info:=copy(bufferstring2.strings[readposition2],oldkomma,komma1-oldkomma);{tyc2}
     val(info,tyc2,error1);
     oldkomma:=komma1+1;

     komma1:=pos(',',bufferstring2.strings[readposition2],oldkomma);
     info:=copy(bufferstring2.strings[readposition2],oldkomma,komma1-oldkomma);{tyc3}
     val(info,tyc3,error1);
     oldkomma:=komma1+1;


//     IF pos(',17,1398,',bufferstring2.strings[readposition2])>0 then
//      beep;

//_RAJ2000,_DEJ2000,TYC1,TYC2,TYC3,pmRA,pmDE,BTmag,VTmag,HIP,RA(ICRS),DE(ICRS)
//deg,deg, , , ,mas/yr,mas/yr,mag,mag, ,deg,deg

     komma1:=pos(',',bufferstring2.strings[readposition2],oldkomma);
     info:=copy(bufferstring2.strings[readposition2],oldkomma,komma1-oldkomma);{pmRA}
     val(info,pmRA,error1);
     oldkomma:=komma1+1;

     komma1:=pos(',',bufferstring2.strings[readposition2],oldkomma);
     info:=copy(bufferstring2.strings[readposition2],oldkomma,komma1-oldkomma); {pmdec}
     val(info,pmDEC,error1);
     oldkomma:=komma1+1;

     komma1:=pos(',',bufferstring2.strings[readposition2],oldkomma);
     info:=copy(bufferstring2.strings[readposition2],oldkomma,komma1-oldkomma);{magBT}
     if pos(' ',info)>0  then error1:=1 else  val(info,magBT,error1);
     oldkomma:=komma1+1;

     komma1:=pos(',',bufferstring2.strings[readposition2],oldkomma);
     info:=copy(bufferstring2.strings[readposition2],oldkomma,komma1-oldkomma); {magVT}
     if pos(' ',info)>0 then error2:=1 else val(info,magVT,error2);
     oldkomma:=komma1+1;



     if ((error1=0) and (error2=0)) then mag1r:=magVT - 0.090 * (magBT - magVT)   {V = VT - 0.090 * (BT - VT)}
     else
     if error1=0 then  mag1R:=MagBT{no VT magnitude, use BT instead 25 stars only}
     else
     if error2=0 then  mag1R:=MagVT
     else
     begin
       mag1R:=9999;
       error_total:=999;
     end;

     mag1:=round(mag1r*10);

    // if mag1>100 then
    // beep;


     komma1:=pos(',',bufferstring2.strings[readposition2],oldkomma);
     info:=copy(bufferstring2.strings[readposition2],oldkomma,komma1-oldkomma); {hip}
     val(info,hip1,error1);
     oldkomma:=komma1+1;

 //    if hip1=9307 then
//     beep;


     if error_total<>0 then mag1:=999 {ignore this star entry, try next }
     else
     begin
       DEC1 {(epoch T)} := (DEC1 + pmDEC * (epoch2 - 1991.25)/(3600*1000))*  (pi/180);  {DEC first}
       RA1  {(epoch T)} := (RA1  + pmRA / cos(dec1)*(epoch2 - 1991.25)/(3600*1000))*(pi/180);
     end;



     inc(readposition2);
   until ((readposition2>=bufferstring2.count) or (error_total=0));


end;


function strtostr_divide10(s1:string):string; {this give much smaller exe file then using strtofloat}
var
   err:integer; r:double;
begin
  val(s1,r,err);
  if err=0 then
  begin
    r:=r/10;
    str(r:0:1,result);
  end;
end;

function floattostr_one_digit(r:double):string;
begin
    str(r:0:1,result);
end;
procedure writetextfile(message1:string);
var F: TextFile;
begin
  AssignFile(F,'result.txt');
  Rewrite(F);
  Writeln(F, message1);
  CloseFile(F);
end;

procedure loadbuffer1(naam1:string); {Gaia}
begin
 with bufferstring1 do
 begin
   try
     LoadFromFile(naam1);	{ load from file }
   except;
    {action none}
     clear;
     beep(200,500);
     main_form.caption:='Error reading file: '+naam1;
   end;
 end;
 readposition1:=1;
end;


procedure loadbuffer2(naam1:string);
begin
 with bufferstring2 do
 begin
   try
     LoadFromFile(naam1);	{ load from file }
   except;
    {action none}
     clear;
     beep(200,500);
     main_form.caption:='Error reading file: '+naam1;
   end;
 end;
 readposition2:=2;
end;


procedure TMain_form.Button1Click(Sender: TObject);
var
  error2 : integer;
  i,j      : integer;
  mag1,mag2 :integer;
  name1  : string;
  info1  : array[0..112] of ansichar;
  ra_g,ra_t,dec_g,dec_t, sep: double;
  star_found  : boolean ;
  myfile           : textfile;

begin
  writetextfile('Started');{clear previous message}

  {make header begin===========================================================}
  {make header end===========================================================}

  {sort file}
  mag_begin:=-2;{start magnitude}
  loadbuffer1(gaia_catalogue.text); {load tycho file in Tstrings}
  loadbuffer2(tycho2_catalogue.text); {load tycho file in Tstrings}

  nr_of_stars:=0;
  AssignFile(myFile, 'result.csv');
  ReWrite(myFile);

  for i:=0 to bufferstring2.count do
  begin
    Application.ProcessMessages; {allow application  to update form1 with above messages}
    if (getasynckeystate(vk_F5))<0  then halt;

    main_form.caption:=('Now doing: '+floattostr_one_digit(i)+' to '+floattostr_one_digit(bufferstring2.count)+ '    Found:  '+inttostr(nr_of_stars)+ '           Magn:  '+inttostr(mag2) );

    read_Tycho(1991.25,ra_t,dec_t, mag2);


    readposition1:=0;
    star_found:=false;
    for j:=0 to bufferstring1.count-1 do
    begin

       read_Gaia(1991.25,ra_g,dec_g,  mag1);
       ang_sep(ra_t,dec_t,ra_g,dec_g, sep);

        if ((sep*(180/pi)<10/(3600)) and (abs(mag1-mag2)<15)) then {10 ARC SEC and magnitudes within 1.5 magnitude}
       begin
         star_found:=true;
       end;
    end;

    if star_found=FALSE then {not in Gaia}
    begin
      inc(nr_of_stars);
      WriteLn(myFile,bufferstring2.strings[readposition2-1]);{tycho star not in Gaia}
    end;
  end;

  CloseFile(myFile);

  writetextfile('Ready.   Stars done:'+ inttostr(nr_of_stars));{write result to file}
  if ((powerdown_enabled.checked)and (nr_of_stars>100)) then statusbar1.simpletext:=ShutMeDown
  else
  messagebox(main_form.handle,pchar('Ready.   Stars done:'+ inttostr(nr_of_stars)),pchar('Ready'),MB_ICONINFORMATION);

end;

procedure TMain_form.FormCreate(Sender: TObject);
begin
  bufferstring1 := Tstringlist.Create;
  bufferstring2 := Tstringlist.Create;
end;

procedure TMain_form.FormDestroy(Sender: TObject);
begin
  bufferstring1.free;{free suppl1}
  bufferstring2.free;{free suppl1}
end;

end.

