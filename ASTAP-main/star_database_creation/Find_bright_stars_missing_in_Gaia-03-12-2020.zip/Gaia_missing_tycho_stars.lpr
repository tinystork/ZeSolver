program Gaia_missing_tycho_stars;

{$MODE Delphi}

uses
  Forms, Interfaces,
  D290conv in 'D290conv.pas' {Main_form},
  Unit_290 in 'Unit_290.pas',
  Unit_tycho2 in 'Unit_tycho2.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TMain_form, Main_form);
  Application.Run;
end.
